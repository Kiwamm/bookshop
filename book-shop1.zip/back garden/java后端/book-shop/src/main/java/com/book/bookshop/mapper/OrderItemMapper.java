package com.book.bookshop.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.book.bookshop.entity.OrderItem;

/**
 * @Auther: jzhang
 * @Date: 2019/9/29 16:36
 * @Description:
 */
public interface OrderItemMapper extends BaseMapper<OrderItem> {
}
