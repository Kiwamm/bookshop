package com.book.bookshop.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.book.bookshop.entity.Address;

/**
 * @Auther: jzhang
 * @Date: 2019/9/29 15:04
 * @Description:
 */
public interface AddressMapper extends BaseMapper<Address> {
}
